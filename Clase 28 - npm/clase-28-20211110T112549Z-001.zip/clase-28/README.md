# Codo a Codo #2153 CRUD en Node.js

## Para Instalar las dependencias

```
npm install
```

## Para ejecutar el server con Express

```
nodemon.cmd app.js
```